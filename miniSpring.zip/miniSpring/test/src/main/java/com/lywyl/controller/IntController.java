package com.lywyl.controller;

import com.lywyl.beans.MyAutowired;
import com.lywyl.servce.TestService;
import com.lywyl.web.mvc.MyController;
import com.lywyl.web.mvc.MyRequestMapping;
import com.lywyl.web.mvc.MyRequestParm;

@MyController
public class IntController {
    @MyAutowired
    private TestService testService;


    @MyRequestMapping("/getstr")
    public String getInteger(@MyRequestParm("before") String before, @MyRequestParm("after") String after){
        return  testService.getstringS(before)+ after;
    }
}
