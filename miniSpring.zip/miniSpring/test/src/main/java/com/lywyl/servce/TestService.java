package com.lywyl.servce;


import com.lywyl.beans.MyBean;

@MyBean
public class TestService {
    public String getstringS(String str){
        return str+"I have use my bean to plus this str";
    }
}
