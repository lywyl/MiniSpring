package com.lywyl.web.server;

import com.lywyl.web.servlet.DispatcherServlet;
import org.apache.catalina.Context;
import org.apache.catalina.LifecycleException;
import org.apache.catalina.core.StandardContext;
import org.apache.catalina.startup.Tomcat;

public class TomcatServer {
    private Tomcat tomcat;
    private String[] args;

    public TomcatServer(String[] args) {

        this.args = args;
    }
    public void startServer() throws LifecycleException {
        tomcat=new Tomcat();
        tomcat.setPort(7788);
        tomcat.start();

        Context context=new StandardContext();
        context.setPath("");
        context.addLifecycleListener(new Tomcat.FixContextListener());
        DispatcherServlet dispatcherServlet=new DispatcherServlet();
        Tomcat.addServlet(context,"dispatcherServlet",dispatcherServlet).setAsyncSupported(true);
        context.addServletMappingDecoded("/","dispatcherServlet");

        tomcat.getHost().addChild(context);

        Thread waitT=new Thread("await_thread"){
            @Override
            public void run(){
                //声明tomcat服务器在等待
                TomcatServer.this.tomcat.getServer().await();
            }
        };

        waitT.setDaemon(false);
        waitT.start();

    }
}
