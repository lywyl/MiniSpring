package com.lywyl.core;
import java.io.IOException;
import java.net.JarURLConnection;
import java.net.URL;
import java.util.*;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

public class ClassScanner {
    public static List<Class<?>> scanClass(String packageName) throws IOException, ClassNotFoundException {
        List<Class<?>> classlist=new ArrayList<>();
        String path=packageName.replace(".","/");
        ClassLoader classLoader=Thread.currentThread().getContextClassLoader();
        Enumeration<URL> resources = classLoader.getResources(path);
        while (resources.hasMoreElements()){
            URL resourse=resources.nextElement();
            if(resourse.getProtocol().contains("jar")){
                JarURLConnection jarURLConnection=(JarURLConnection) resourse.openConnection();
                String jarPath=jarURLConnection.getJarFile().getName();
                classlist.addAll(getClassFromJar(jarPath,path));
            }else {
                //
            }
        }
        return classlist;
    }

        static List<Class<?>> getClassFromJar(String jarPath,String path) throws IOException, ClassNotFoundException {
        List<Class<?>> classes=new ArrayList<>();
        JarFile jarFile= new JarFile(jarPath);
        Enumeration<JarEntry> jarEnties=jarFile.entries();
        while (jarEnties.hasMoreElements()){
            JarEntry jarEntry=jarEnties.nextElement();
            String entrtName=jarEntry.getName();
            if(entrtName.startsWith(path)&&entrtName.endsWith(".class")){
                String fullClassName=entrtName.replace("/",".").substring(0, entrtName.length()-6);
                classes.add(Class.forName(fullClassName));

            }
        }
        return classes;
    }
}
