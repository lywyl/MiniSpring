package com.lywyl.web.handler;
import com.lywyl.web.mvc.MyController;
import com.lywyl.web.mvc.MyRequestMapping;
import com.lywyl.web.mvc.MyRequestParm;

import java.lang.reflect.*;
import java.util.*;
public class HandlerManager {
    public static List<MappingHandler> mappingHandlerList=new ArrayList<>();
    public static void resolveMappingHandler(List<Class<?>> classList){
        for(Class<?> cls:classList){
            if(cls.isAnnotationPresent(MyController.class)){
                parseHandlerFromController(cls);
            }

        }
    }
    //通过反射得到类的方fa
    private static void parseHandlerFromController(Class<?> cls){
        Method[] methods=cls.getDeclaredMethods();
        for(Method method:methods){
            if(!method.isAnnotationPresent(MyRequestMapping.class)){
                continue;
            }
            String url=method.getDeclaredAnnotation(MyRequestMapping.class).value();
            List<String> paramList=new ArrayList<>();
            for(Parameter parameter:method.getParameters()){
                if(parameter.isAnnotationPresent(MyRequestParm.class)){
                    paramList.add(parameter.getDeclaredAnnotation(MyRequestParm.class).value());
                }
            }
            String[] params=paramList.toArray(new String[paramList.size()]);

            MappingHandler mappingHandler=new MappingHandler(url,method,cls,params);
            HandlerManager.mappingHandlerList.add(mappingHandler);
        }
    }
}
