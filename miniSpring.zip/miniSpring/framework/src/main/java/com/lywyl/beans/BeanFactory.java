package com.lywyl.beans;

import com.lywyl.web.mvc.MyController;
import com.lywyl.web.mvc.MyRequestMapping;

import java.lang.reflect.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class BeanFactory {
    private static Map<Class<?>,Object> classToBean=new ConcurrentHashMap<>();


    public static Object getBean(Class<?> cls){
        return classToBean.get(cls);

    }
    public static void initBean(List<Class<?>> list) throws Exception {
        List<Class<?>> toCreate=new ArrayList<>(list);
        while (toCreate.size()!=0){
            int curlen=toCreate.size();
            for (int i = 0; i < toCreate.size(); i++) {
                if(finishCreate(toCreate.get(i))){
                    toCreate.remove(i);
                }
                if(toCreate.size()==curlen){
                    throw new Exception("cycle dependency!");

                }
            }
        }
    }

    public static boolean finishCreate(Class<?> cls) throws IllegalAccessException, InstantiationException {
        if(!cls.isAnnotationPresent(MyBean.class)&& !cls.isAnnotationPresent(MyController.class)){
            return true;
        }
        Object bean=cls.newInstance();
        for(Field field:cls.getDeclaredFields()){
            if(field.isAnnotationPresent(MyAutowired.class)){
                Class<?> filedType= field.getType();
                Object relianBean=BeanFactory.getBean(filedType);
                if(relianBean==null){
                    return false;
                }
                field.setAccessible(true);
                field.set(bean,relianBean);
            }

        }
        classToBean.put(cls,bean);
        return true;
    }
}
