package com.lywyl.web.handler;

import com.lywyl.beans.BeanFactory;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class MappingHandler {
    private String url;
    private Method method;
    private Class<?> controller;
    private String[] args;


    public MappingHandler(String url, Method method, Class<?> controller, String[] args) {
        this.url = url;
        this.method = method;
        this.controller = controller;
        this.args = args;
    }

    public boolean handle(ServletRequest req, ServletResponse res) throws IllegalAccessException, InstantiationException, InvocationTargetException, IOException {
        String reqUrl= ((HttpServletRequest)req).getRequestURI();
        if(!url.equals(reqUrl)){
            return false;
        }
        Object[] parameters=new Object[args.length];
        for (int i = 0; i < args.length; i++) {
            parameters[i] = req.getParameter(args[i]);
        }

        Object ctl= BeanFactory.getBean(controller);
        Object response=method.invoke(ctl,parameters);
        res.getWriter().println(response.toString());
        return true;
    }

}
