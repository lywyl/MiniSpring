package com.lywyl.starter;

import com.lywyl.beans.BeanFactory;
import com.lywyl.core.ClassScanner;
import com.lywyl.web.handler.HandlerManager;
import com.lywyl.web.server.TomcatServer;

import java.io.IOException;
import java.util.*;
import org.apache.catalina.LifecycleException;

public class MiniApplication {
    public static void run(Class<?> cla,String[] args){
        System.out.println("hello miniOne");

        TomcatServer aServer=new TomcatServer(args);
        try {
            aServer.startServer();
            List<Class<?>> list= ClassScanner.scanClass(cla.getPackage().getName());
            BeanFactory.initBean(list);
            //查看是否加载扫描了全部类
            //list.forEach(it-> System.out.println(it.getName()));

            HandlerManager.resolveMappingHandler(list);
        } catch (LifecycleException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
